import "server-only";

import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/db";
import {
  getTemplateParameterKeys,
  type WhatsAppEventKey,
} from "@/lib/whatsapp/defaults";
import {
  getWhatsAppRuntimeStatus,
  MetaCloudApiError,
  normalizeWhatsAppPhone,
  sendMetaTemplateMessage,
} from "@/lib/whatsapp/meta-cloud";

const MAX_SEND_ATTEMPTS = 4;

type QueueTemplateMessageInput = {
  eventKey: WhatsAppEventKey;
  recipientPhone: string;
  recipientName?: string | null;
  parameterValues?: string[];
  dedupeKey?: string | null;
  relatedEntityType?: string | null;
  relatedEntityId?: string | null;
  relatedNotificationId?: string | null;
  createdById?: string | null;
  createdByName?: string | null;
  allowWhenDisabled?: boolean;
};

type DispatchOptions = {
  allowWhenDisabled?: boolean;
  finalOnFailure?: boolean;
};

function asInputJson(value: unknown) {
  return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
}

function retryDelayMilliseconds(attempts: number) {
  const minutes = Math.min(120, 5 * 2 ** Math.max(0, attempts - 1));
  return minutes * 60 * 1000;
}

function safeErrorMessage(error: unknown) {
  if (error instanceof Error) return error.message.slice(0, 1000);
  return "Unknown WhatsApp delivery error.";
}

function errorCode(error: unknown) {
  if (error instanceof MetaCloudApiError) return error.code;
  return null;
}

export async function queueWhatsAppTemplateMessage({
  eventKey,
  recipientPhone,
  recipientName,
  parameterValues = [],
  dedupeKey,
  relatedEntityType,
  relatedEntityId,
  relatedNotificationId,
  createdById,
  createdByName,
  allowWhenDisabled = false,
}: QueueTemplateMessageInput) {
  const [configuration, template] = await Promise.all([
    prisma.whatsAppConfiguration.findUnique({
      where: {
        id: "primary",
      },
    }),
    prisma.whatsAppTemplate.findUnique({
      where: {
        eventKey,
      },
    }),
  ]);

  if (!configuration) {
    throw new Error(
      "WhatsApp configuration is missing. Apply the database migration first.",
    );
  }

  if (!template) {
    throw new Error(`WhatsApp template mapping ${eventKey} is missing.`);
  }

  if (!allowWhenDisabled && !configuration.isEnabled) {
    throw new Error("Automatic WhatsApp delivery is disabled.");
  }

  if (!allowWhenDisabled && !template.isEnabled) {
    throw new Error(`${template.displayName} WhatsApp template is disabled.`);
  }

  const parameterKeys = getTemplateParameterKeys(template.parameterKeys);

  if (parameterValues.length !== parameterKeys.length) {
    throw new Error(
      `${template.displayName} requires ${parameterKeys.length} template parameter${parameterKeys.length === 1 ? "" : "s"}.`,
    );
  }

  const normalizedRecipient = normalizeWhatsAppPhone(
    recipientPhone,
    configuration.defaultCountryCode,
  );
  const normalizedDedupeKey = dedupeKey?.trim().slice(0, 240) || null;

  if (normalizedDedupeKey) {
    const existing = await prisma.whatsAppMessage.findUnique({
      where: {
        dedupeKey: normalizedDedupeKey,
      },
    });

    if (existing) return existing;
  }

  try {
    return await prisma.whatsAppMessage.create({
      data: {
        direction: "OUTBOUND",
        eventKey,
        recipientPhone: normalizedRecipient,
        recipientName: recipientName?.trim().slice(0, 160) || null,
        templateName: template.templateName,
        languageCode: template.languageCode,
        payload: asInputJson({
          parameterKeys,
          parameterValues: parameterValues.map((value) =>
            String(value).slice(0, 1024),
          ),
        }),
        status: "PENDING",
        dedupeKey: normalizedDedupeKey,
        relatedEntityType:
          relatedEntityType?.trim().slice(0, 80) || null,
        relatedEntityId: relatedEntityId?.trim().slice(0, 160) || null,
        relatedNotificationId:
          relatedNotificationId?.trim().slice(0, 160) || null,
        createdById: createdById?.trim().slice(0, 160) || null,
        createdByName: createdByName?.trim().slice(0, 160) || null,
      },
    });
  } catch (error) {
    if (
      normalizedDedupeKey &&
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    ) {
      const existing = await prisma.whatsAppMessage.findUnique({
        where: {
          dedupeKey: normalizedDedupeKey,
        },
      });

      if (existing) return existing;
    }

    throw error;
  }
}

function payloadParameterValues(payload: Prisma.JsonValue) {
  if (
    !payload ||
    typeof payload !== "object" ||
    Array.isArray(payload) ||
    !("parameterValues" in payload)
  ) {
    return [];
  }

  const values = payload.parameterValues;
  if (!Array.isArray(values)) return [];

  return values.filter((value): value is string => typeof value === "string");
}

export async function dispatchWhatsAppMessageById(
  messageId: string,
  {
    allowWhenDisabled = false,
    finalOnFailure = false,
  }: DispatchOptions = {},
) {
  const [configuration, message] = await Promise.all([
    prisma.whatsAppConfiguration.findUnique({
      where: {
        id: "primary",
      },
    }),
    prisma.whatsAppMessage.findUnique({
      where: {
        id: messageId,
      },
    }),
  ]);

  if (!configuration) {
    throw new Error("WhatsApp configuration is missing.");
  }

  if (!message || message.direction !== "OUTBOUND") {
    throw new Error("Outbound WhatsApp message was not found.");
  }

  if (!allowWhenDisabled && !configuration.isEnabled) {
    throw new Error("Automatic WhatsApp delivery is disabled.");
  }

  if (
    ["SENT", "DELIVERED", "READ"].includes(message.status) &&
    message.providerMessageId
  ) {
    return message;
  }

  if (
    !message.recipientPhone ||
    !message.templateName ||
    !message.languageCode
  ) {
    throw new Error("WhatsApp message payload is incomplete.");
  }

  const runtimeStatus = getWhatsAppRuntimeStatus();
  if (!runtimeStatus.sendReady) {
    throw new Error(
      `WhatsApp send configuration is incomplete: ${runtimeStatus.missingForSend.join(", ")}.`,
    );
  }

  const claimed = await prisma.whatsAppMessage.updateMany({
    where: {
      id: message.id,
      status: {
        in: ["PENDING", "FAILED"],
      },
    },
    data: {
      status: "PROCESSING",
      attempts: {
        increment: 1,
      },
      lastAttemptAt: new Date(),
      nextAttemptAt: null,
      errorCode: null,
      errorMessage: null,
      failedAt: null,
    },
  });

  if (claimed.count !== 1) {
    return prisma.whatsAppMessage.findUniqueOrThrow({
      where: {
        id: message.id,
      },
    });
  }

  const nextAttempts = message.attempts + 1;

  try {
    const result = await sendMetaTemplateMessage({
      recipientPhone: message.recipientPhone,
      templateName: message.templateName,
      languageCode: message.languageCode,
      parameterValues: payloadParameterValues(message.payload),
    });

    return await prisma.whatsAppMessage.update({
      where: {
        id: message.id,
      },
      data: {
        status: "SENT",
        providerMessageId: result.providerMessageId,
        sentAt: new Date(),
        nextAttemptAt: null,
        errorCode: null,
        errorMessage: null,
      },
    });
  } catch (error) {
    const shouldRetry =
      !finalOnFailure && nextAttempts < MAX_SEND_ATTEMPTS;
    const retryAt = shouldRetry
      ? new Date(Date.now() + retryDelayMilliseconds(nextAttempts))
      : null;

    await prisma.whatsAppMessage.update({
      where: {
        id: message.id,
      },
      data: {
        status: shouldRetry ? "PENDING" : "FAILED",
        nextAttemptAt: retryAt,
        errorCode: errorCode(error),
        errorMessage: safeErrorMessage(error),
        failedAt: shouldRetry ? null : new Date(),
      },
    });

    throw error;
  }
}

export async function dispatchQueuedWhatsAppMessages(limit = 20) {
  const configuration = await prisma.whatsAppConfiguration.findUnique({
    where: {
      id: "primary",
    },
  });

  if (!configuration?.isEnabled) {
    return {
      selected: 0,
      sent: 0,
      failed: 0,
      skipped: true,
    };
  }

  // Recover jobs left in PROCESSING when a server instance stopped between
  // claiming a row and recording Meta's response.
  await prisma.whatsAppMessage.updateMany({
    where: {
      direction: "OUTBOUND",
      status: "PROCESSING",
      OR: [
        {
          lastAttemptAt: null,
        },
        {
          lastAttemptAt: {
            lt: new Date(Date.now() - 10 * 60 * 1000),
          },
        },
      ],
    },
    data: {
      status: "PENDING",
      nextAttemptAt: new Date(),
      errorCode: "STALE_PROCESS_RECOVERED",
      errorMessage:
        "Recovered after an interrupted dispatcher run; delivery will be retried.",
    },
  });

  const messages = await prisma.whatsAppMessage.findMany({
    where: {
      direction: "OUTBOUND",
      status: "PENDING",
      OR: [
        {
          nextAttemptAt: null,
        },
        {
          nextAttemptAt: {
            lte: new Date(),
          },
        },
      ],
    },
    orderBy: {
      createdAt: "asc",
    },
    take: Math.min(Math.max(limit, 1), 100),
  });

  let sent = 0;
  let failed = 0;

  for (const message of messages) {
    try {
      const result = await dispatchWhatsAppMessageById(message.id);
      if (["SENT", "DELIVERED", "READ"].includes(result.status)) sent += 1;
    } catch {
      failed += 1;
    }
  }

  return {
    selected: messages.length,
    sent,
    failed,
    skipped: false,
  };
}

export async function resetWhatsAppMessageForRetry(messageId: string) {
  return prisma.whatsAppMessage.update({
    where: {
      id: messageId,
    },
    data: {
      status: "PENDING",
      attempts: 0,
      nextAttemptAt: null,
      lastAttemptAt: null,
      errorCode: null,
      errorMessage: null,
      failedAt: null,
      providerMessageId: null,
      sentAt: null,
      deliveredAt: null,
      readAt: null,
    },
  });
}
