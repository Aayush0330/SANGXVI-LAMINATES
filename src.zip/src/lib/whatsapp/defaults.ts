import "server-only";

import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/db";

export const WHATSAPP_CONFIGURATION_ID = "primary";

export const WHATSAPP_TEMPLATE_DEFAULTS = [
  {
    id: "wa-template-test",
    eventKey: "TEST_MESSAGE",
    displayName: "Connection test",
    templateName: "hello_world",
    languageCode: "en_US",
    parameterKeys: [],
    isEnabled: true,
  },
  {
    id: "wa-template-order-received",
    eventKey: "ORDER_RECEIVED",
    displayName: "Order received",
    templateName: "sanghvi_order_received",
    languageCode: "en",
    parameterKeys: ["orderNumber", "customerName"],
    isEnabled: false,
  },
  {
    id: "wa-template-stock-blocked",
    eventKey: "STOCK_BLOCKED",
    displayName: "Stock blocked",
    templateName: "sanghvi_stock_blocked",
    languageCode: "en",
    parameterKeys: ["orderNumber"],
    isEnabled: false,
  },
  {
    id: "wa-template-qc-approved",
    eventKey: "QC_APPROVED",
    displayName: "QC approved",
    templateName: "sanghvi_qc_approved",
    languageCode: "en",
    parameterKeys: ["orderNumber"],
    isEnabled: false,
  },
  {
    id: "wa-template-transport-assigned",
    eventKey: "TRANSPORT_ASSIGNED",
    displayName: "Transport assigned",
    templateName: "sanghvi_transport_assigned",
    languageCode: "en",
    parameterKeys: ["orderNumber", "driverName"],
    isEnabled: false,
  },
  {
    id: "wa-template-order-on-way",
    eventKey: "ORDER_ON_THE_WAY",
    displayName: "Order on the way",
    templateName: "sanghvi_order_on_the_way",
    languageCode: "en",
    parameterKeys: ["orderNumber"],
    isEnabled: false,
  },
  {
    id: "wa-template-order-delivered",
    eventKey: "ORDER_DELIVERED",
    displayName: "Order delivered",
    templateName: "sanghvi_order_delivered",
    languageCode: "en",
    parameterKeys: ["orderNumber"],
    isEnabled: false,
  },
  {
    id: "wa-template-low-stock",
    eventKey: "LOW_STOCK",
    displayName: "Low stock alert",
    templateName: "sanghvi_low_stock",
    languageCode: "en",
    parameterKeys: ["productName", "availableQuantity"],
    isEnabled: false,
  },
  {
    id: "wa-template-blocker",
    eventKey: "BLOCKER",
    displayName: "Workflow blocker",
    templateName: "sanghvi_workflow_blocker",
    languageCode: "en",
    parameterKeys: ["reference", "reason"],
    isEnabled: false,
  },
] as const;

export type WhatsAppEventKey =
  (typeof WHATSAPP_TEMPLATE_DEFAULTS)[number]["eventKey"];

export function isWhatsAppEventKey(value: string): value is WhatsAppEventKey {
  return WHATSAPP_TEMPLATE_DEFAULTS.some(
    (template) => template.eventKey === value,
  );
}

export async function ensureWhatsAppDefaults() {
  const configuration = await prisma.whatsAppConfiguration.upsert({
    where: {
      id: WHATSAPP_CONFIGURATION_ID,
    },
    update: {},
    create: {
      id: WHATSAPP_CONFIGURATION_ID,
      provider: "META_CLOUD",
      isEnabled: false,
      businessDisplayName: "Sanghvi ERP",
      defaultCountryCode: "91",
    },
  });

  await prisma.whatsAppTemplate.createMany({
    data: WHATSAPP_TEMPLATE_DEFAULTS.map((template) => ({
      id: template.id,
      eventKey: template.eventKey,
      displayName: template.displayName,
      templateName: template.templateName,
      languageCode: template.languageCode,
      parameterKeys:
        template.parameterKeys as unknown as Prisma.InputJsonValue,
      isEnabled: template.isEnabled,
    })),
    skipDuplicates: true,
  });

  return configuration;
}

export function getTemplateParameterKeys(value: Prisma.JsonValue) {
  if (!Array.isArray(value)) return [];
  return value.filter(
    (parameter): parameter is string => typeof parameter === "string",
  );
}
