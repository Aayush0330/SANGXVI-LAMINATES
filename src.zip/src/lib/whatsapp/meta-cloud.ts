import "server-only";

const META_GRAPH_ORIGIN = "https://graph.facebook.com";
const TEMPLATE_NAME_PATTERN = /^[a-z0-9_]+$/;
const LANGUAGE_CODE_PATTERN = /^[a-z]{2,3}(?:_[A-Z]{2})?$/;
const GRAPH_VERSION_PATTERN = /^v\d+\.\d+$/;

type MetaErrorPayload = {
  error?: {
    message?: string;
    type?: string;
    code?: number;
    error_subcode?: number;
    fbtrace_id?: string;
  };
};

type MetaSendResponse = MetaErrorPayload & {
  messaging_product?: string;
  contacts?: Array<{
    input?: string;
    wa_id?: string;
  }>;
  messages?: Array<{
    id?: string;
    message_status?: string;
  }>;
};

export type WhatsAppRuntimeStatus = {
  provider: "META_CLOUD";
  graphApiVersionConfigured: boolean;
  phoneNumberIdConfigured: boolean;
  wabaIdConfigured: boolean;
  accessTokenConfigured: boolean;
  appSecretConfigured: boolean;
  webhookVerifyTokenConfigured: boolean;
  sendReady: boolean;
  webhookReady: boolean;
  automaticReady: boolean;
  maskedPhoneNumberId: string | null;
  maskedWabaId: string | null;
  missingForSend: string[];
  missingForWebhook: string[];
  missingForAutomatic: string[];
};

export type MetaTemplateSendInput = {
  recipientPhone: string;
  templateName: string;
  languageCode: string;
  parameterValues?: string[];
};

export type MetaTemplateSendResult = {
  providerMessageId: string;
  acceptedRecipient: string | null;
  messageStatus: string | null;
};

export class MetaCloudApiError extends Error {
  readonly status: number;
  readonly code: string | null;

  constructor(message: string, status: number, code?: string | number | null) {
    super(message);
    this.name = "MetaCloudApiError";
    this.status = status;
    this.code = code === null || code === undefined ? null : String(code);
  }
}

function cleanEnvironmentValue(value: string | undefined) {
  const normalized = value?.trim();
  return normalized || null;
}

function maskIdentifier(value: string | null) {
  if (!value) return null;
  if (value.length <= 6) return "••••••";
  return `${value.slice(0, 2)}••••••${value.slice(-4)}`;
}

function getRuntimeConfiguration() {
  return {
    graphApiVersion: cleanEnvironmentValue(
      process.env.WHATSAPP_GRAPH_API_VERSION,
    ),
    phoneNumberId: cleanEnvironmentValue(
      process.env.WHATSAPP_PHONE_NUMBER_ID,
    ),
    wabaId: cleanEnvironmentValue(process.env.WHATSAPP_WABA_ID),
    accessToken: cleanEnvironmentValue(process.env.WHATSAPP_ACCESS_TOKEN),
    appSecret: cleanEnvironmentValue(process.env.WHATSAPP_APP_SECRET),
    webhookVerifyToken: cleanEnvironmentValue(
      process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN,
    ),
  };
}

export function getWhatsAppRuntimeStatus(): WhatsAppRuntimeStatus {
  const configuration = getRuntimeConfiguration();
  const missingForSend: string[] = [];
  const missingForWebhook: string[] = [];
  const missingForAutomatic: string[] = [];

  if (!configuration.graphApiVersion) {
    missingForSend.push("WHATSAPP_GRAPH_API_VERSION");
  } else if (!GRAPH_VERSION_PATTERN.test(configuration.graphApiVersion)) {
    missingForSend.push("WHATSAPP_GRAPH_API_VERSION (expected vXX.X)");
  }

  if (!configuration.phoneNumberId) {
    missingForSend.push("WHATSAPP_PHONE_NUMBER_ID");
  }

  if (!configuration.accessToken) {
    missingForSend.push("WHATSAPP_ACCESS_TOKEN");
  }

  if (!configuration.appSecret) {
    missingForWebhook.push("WHATSAPP_APP_SECRET");
  }

  if (!configuration.webhookVerifyToken) {
    missingForWebhook.push("WHATSAPP_WEBHOOK_VERIFY_TOKEN");
  }

  missingForAutomatic.push(...missingForSend, ...missingForWebhook);

  if (!configuration.wabaId) {
    missingForAutomatic.push("WHATSAPP_WABA_ID");
  }

  return {
    provider: "META_CLOUD",
    graphApiVersionConfigured: Boolean(
      configuration.graphApiVersion &&
        GRAPH_VERSION_PATTERN.test(configuration.graphApiVersion),
    ),
    phoneNumberIdConfigured: Boolean(configuration.phoneNumberId),
    wabaIdConfigured: Boolean(configuration.wabaId),
    accessTokenConfigured: Boolean(configuration.accessToken),
    appSecretConfigured: Boolean(configuration.appSecret),
    webhookVerifyTokenConfigured: Boolean(
      configuration.webhookVerifyToken,
    ),
    sendReady: missingForSend.length === 0,
    webhookReady: missingForWebhook.length === 0,
    automaticReady: missingForAutomatic.length === 0,
    maskedPhoneNumberId: maskIdentifier(configuration.phoneNumberId),
    maskedWabaId: maskIdentifier(configuration.wabaId),
    missingForSend,
    missingForWebhook,
    missingForAutomatic: Array.from(new Set(missingForAutomatic)),
  };
}

export function getWhatsAppWebhookVerifyToken() {
  return getRuntimeConfiguration().webhookVerifyToken;
}

export function getWhatsAppAppSecret() {
  return getRuntimeConfiguration().appSecret;
}

export function getWhatsAppAssetIdentity() {
  const configuration = getRuntimeConfiguration();
  return {
    phoneNumberId: configuration.phoneNumberId,
    wabaId: configuration.wabaId,
  };
}

export function normalizeWhatsAppPhone(
  input: string,
  defaultCountryCode = "91",
) {
  const raw = input.trim();
  const digits = raw.replace(/\D/g, "");
  const countryCode = defaultCountryCode.replace(/\D/g, "");
  const explicitlyInternational = raw.startsWith("+");

  let normalized = digits;

  if (!explicitlyInternational && digits.length === 10) {
    normalized = `${countryCode}${digits}`;
  } else if (
    !explicitlyInternational &&
    digits.length === 11 &&
    digits.startsWith("0")
  ) {
    normalized = `${countryCode}${digits.slice(1)}`;
  }

  if (
    !countryCode ||
    countryCode.length > 4 ||
    normalized.length < 8 ||
    normalized.length > 15 ||
    normalized.startsWith("0")
  ) {
    throw new Error(
      "Enter a valid WhatsApp number with country code, for example +919876543210.",
    );
  }

  return normalized;
}

export function maskWhatsAppPhone(value: string | null | undefined) {
  if (!value) return "—";
  const digits = value.replace(/\D/g, "");
  if (digits.length <= 4) return "••••";
  return `+${digits.slice(0, 2)} •••••• ${digits.slice(-4)}`;
}

export function validateWhatsAppTemplateName(value: string) {
  return TEMPLATE_NAME_PATTERN.test(value);
}

export function validateWhatsAppLanguageCode(value: string) {
  return LANGUAGE_CODE_PATTERN.test(value);
}

export async function sendMetaTemplateMessage({
  recipientPhone,
  templateName,
  languageCode,
  parameterValues = [],
}: MetaTemplateSendInput): Promise<MetaTemplateSendResult> {
  const configuration = getRuntimeConfiguration();
  const runtimeStatus = getWhatsAppRuntimeStatus();

  if (!runtimeStatus.sendReady) {
    throw new MetaCloudApiError(
      `WhatsApp send configuration is incomplete: ${runtimeStatus.missingForSend.join(", ")}.`,
      503,
      "CONFIGURATION_INCOMPLETE",
    );
  }

  if (!validateWhatsAppTemplateName(templateName)) {
    throw new MetaCloudApiError(
      "The configured Meta template name is invalid.",
      400,
      "INVALID_TEMPLATE_NAME",
    );
  }

  if (!validateWhatsAppLanguageCode(languageCode)) {
    throw new MetaCloudApiError(
      "The configured Meta template language is invalid.",
      400,
      "INVALID_LANGUAGE_CODE",
    );
  }

  const template: Record<string, unknown> = {
    name: templateName,
    language: {
      code: languageCode,
    },
  };

  if (parameterValues.length > 0) {
    template.components = [
      {
        type: "body",
        parameters: parameterValues.map((value) => ({
          type: "text",
          text: value.slice(0, 1024),
        })),
      },
    ];
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);

  let response: Response;

  try {
    response = await fetch(
      `${META_GRAPH_ORIGIN}/${configuration.graphApiVersion}/${configuration.phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${configuration.accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          recipient_type: "individual",
          to: recipientPhone,
          type: "template",
          template,
        }),
        cache: "no-store",
        signal: controller.signal,
      },
    );
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") {
      throw new MetaCloudApiError(
        "Meta Cloud API request timed out.",
        504,
        "REQUEST_TIMEOUT",
      );
    }

    throw new MetaCloudApiError(
      "Meta Cloud API could not be reached.",
      502,
      "NETWORK_ERROR",
    );
  } finally {
    clearTimeout(timeout);
  }

  const payload = (await response.json().catch(() => ({}))) as MetaSendResponse;

  if (!response.ok) {
    throw new MetaCloudApiError(
      payload.error?.message || "Meta Cloud API rejected the message.",
      response.status,
      payload.error?.code ?? payload.error?.type ?? null,
    );
  }

  const providerMessageId = payload.messages?.[0]?.id;

  if (!providerMessageId) {
    throw new MetaCloudApiError(
      "Meta Cloud API accepted the request without returning a message ID.",
      502,
      "MISSING_MESSAGE_ID",
    );
  }

  return {
    providerMessageId,
    acceptedRecipient: payload.contacts?.[0]?.wa_id ?? null,
    messageStatus: payload.messages?.[0]?.message_status ?? null,
  };
}
