import "server-only";

import { Prisma } from "@/generated/prisma/client";
import { prisma } from "@/lib/db";
import { getWhatsAppAssetIdentity } from "@/lib/whatsapp/meta-cloud";

type MetaWebhookStatus = {
  id?: string;
  status?: string;
  timestamp?: string;
  recipient_id?: string;
  errors?: Array<{
    code?: number;
    title?: string;
    message?: string;
    error_data?: {
      details?: string;
    };
  }>;
};

type MetaWebhookMessage = {
  id?: string;
  from?: string;
  timestamp?: string;
  type?: string;
  [key: string]: unknown;
};

type MetaWebhookValue = {
  messaging_product?: string;
  metadata?: {
    display_phone_number?: string;
    phone_number_id?: string;
  };
  contacts?: unknown[];
  messages?: MetaWebhookMessage[];
  statuses?: MetaWebhookStatus[];
};

type MetaWebhookPayload = {
  object?: string;
  entry?: Array<{
    id?: string;
    changes?: Array<{
      field?: string;
      value?: MetaWebhookValue;
    }>;
  }>;
};

export class WhatsAppWebhookAssetMismatchError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "WhatsAppWebhookAssetMismatchError";
  }
}

function asInputJson(value: unknown) {
  return JSON.parse(JSON.stringify(value)) as Prisma.InputJsonValue;
}

function normalizedDigits(value: string | undefined) {
  return value?.replace(/\D/g, "") || null;
}

function providerTimestamp(value: string | undefined) {
  const seconds = Number(value);
  if (!Number.isFinite(seconds) || seconds <= 0) return new Date();
  return new Date(seconds * 1000);
}

function statusRank(status: string) {
  switch (status) {
    case "READ":
      return 50;
    case "DELIVERED":
      return 40;
    case "FAILED":
      return 35;
    case "SENT":
      return 30;
    case "PROCESSING":
      return 20;
    case "PENDING":
      return 10;
    default:
      return 0;
  }
}

function getEventType(payload: MetaWebhookPayload) {
  let hasMessages = false;
  let hasStatuses = false;

  for (const entry of payload.entry ?? []) {
    for (const change of entry.changes ?? []) {
      if ((change.value?.messages?.length ?? 0) > 0) hasMessages = true;
      if ((change.value?.statuses?.length ?? 0) > 0) hasStatuses = true;
    }
  }

  if (hasMessages && hasStatuses) return "MESSAGES_AND_STATUSES";
  if (hasMessages) return "INBOUND_MESSAGE";
  if (hasStatuses) return "MESSAGE_STATUS";
  return "OTHER";
}

function assertConfiguredAsset(payload: MetaWebhookPayload) {
  if (
    !payload ||
    typeof payload !== "object" ||
    payload.object !== "whatsapp_business_account"
  ) {
    throw new WhatsAppWebhookAssetMismatchError(
      "Webhook object is not a WhatsApp Business Account.",
    );
  }

  const identity = getWhatsAppAssetIdentity();

  for (const entry of payload.entry ?? []) {
    if (identity.wabaId && entry.id !== identity.wabaId) {
      throw new WhatsAppWebhookAssetMismatchError(
        "Webhook WhatsApp Business Account does not match the configured account.",
      );
    }

    for (const change of entry.changes ?? []) {
      if (
        identity.phoneNumberId &&
        change.field === "messages" &&
        change.value?.metadata?.phone_number_id !== identity.phoneNumberId
      ) {
        throw new WhatsAppWebhookAssetMismatchError(
          "Webhook phone number does not match the configured phone number.",
        );
      }
    }
  }
}

function statusError(status: MetaWebhookStatus) {
  const error = status.errors?.[0];
  if (!error) {
    return {
      code: null,
      message: null,
    };
  }

  return {
    code: error.code === undefined ? null : String(error.code),
    message: (
      error.error_data?.details ||
      error.message ||
      error.title ||
      "Meta reported a WhatsApp delivery failure."
    ).slice(0, 1000),
  };
}

async function applyMessageStatus(status: MetaWebhookStatus) {
  if (!status.id || !status.status) return;

  const incomingStatus = status.status.toUpperCase();
  if (!["SENT", "DELIVERED", "READ", "FAILED"].includes(incomingStatus)) {
    return;
  }

  const message = await prisma.whatsAppMessage.findUnique({
    where: {
      providerMessageId: status.id,
    },
  });

  if (!message || statusRank(incomingStatus) < statusRank(message.status)) {
    return;
  }

  const occurredAt = providerTimestamp(status.timestamp);
  const failure = statusError(status);
  const timestampUpdate =
    incomingStatus === "SENT"
      ? { sentAt: occurredAt }
      : incomingStatus === "DELIVERED"
        ? { deliveredAt: occurredAt }
        : incomingStatus === "READ"
          ? { readAt: occurredAt }
          : { failedAt: occurredAt };

  await prisma.whatsAppMessage.update({
    where: {
      id: message.id,
    },
    data: {
      status: incomingStatus,
      ...timestampUpdate,
      nextAttemptAt: null,
      errorCode: incomingStatus === "FAILED" ? failure.code : null,
      errorMessage: incomingStatus === "FAILED" ? failure.message : null,
    },
  });
}

async function recordInboundMessage(
  message: MetaWebhookMessage,
  value: MetaWebhookValue,
) {
  if (!message.id || !message.from) return;

  const senderPhone = normalizedDigits(message.from);
  const recipientPhone = normalizedDigits(
    value.metadata?.display_phone_number,
  );

  await prisma.whatsAppMessage.upsert({
    where: {
      providerMessageId: message.id,
    },
    update: {
      payload: asInputJson({
        message,
        contacts: value.contacts ?? [],
        metadata: value.metadata ?? {},
      }),
    },
    create: {
      direction: "INBOUND",
      eventKey: "INBOUND_MESSAGE",
      senderPhone,
      recipientPhone,
      payload: asInputJson({
        message,
        contacts: value.contacts ?? [],
        metadata: value.metadata ?? {},
      }),
      status: "RECEIVED",
      providerMessageId: message.id,
      sentAt: providerTimestamp(message.timestamp),
    },
  });
}

async function processChanges(payload: MetaWebhookPayload) {
  for (const entry of payload.entry ?? []) {
    for (const change of entry.changes ?? []) {
      const value = change.value;
      if (!value) continue;

      for (const message of value.messages ?? []) {
        await recordInboundMessage(message, value);
      }

      for (const status of value.statuses ?? []) {
        await applyMessageStatus(status);
      }
    }
  }
}

export async function processWhatsAppWebhook({
  payloadHash,
  payload,
}: {
  payloadHash: string;
  payload: unknown;
}) {
  const normalizedPayload = payload as MetaWebhookPayload;
  assertConfiguredAsset(normalizedPayload);
  const eventType = getEventType(normalizedPayload);
  let event = await prisma.whatsAppWebhookEvent.findUnique({
    where: {
      payloadHash,
    },
  });

  if (event?.processedAt) {
    return {
      duplicate: true,
      eventId: event.id,
      eventType: event.eventType ?? eventType,
    };
  }

  if (!event) {
    try {
      event = await prisma.whatsAppWebhookEvent.create({
        data: {
          payloadHash,
          eventType,
          payload: asInputJson(payload),
        },
      });
    } catch (error) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002"
      ) {
        event = await prisma.whatsAppWebhookEvent.findUnique({
          where: {
            payloadHash,
          },
        });
      } else {
        throw error;
      }
    }
  }

  if (!event) {
    throw new Error("WhatsApp webhook event could not be recorded.");
  }

  try {
    await processChanges(normalizedPayload);
    const processedAt = new Date();

    await Promise.all([
      prisma.whatsAppWebhookEvent.update({
        where: {
          id: event.id,
        },
        data: {
          eventType,
          processedAt,
          errorMessage: null,
        },
      }),
      prisma.whatsAppConfiguration.upsert({
        where: {
          id: "primary",
        },
        update: {
          lastWebhookAt: processedAt,
          lastWebhookEventType: eventType,
        },
        create: {
          id: "primary",
          provider: "META_CLOUD",
          isEnabled: false,
          businessDisplayName: "Sanghvi ERP",
          defaultCountryCode: "91",
          lastWebhookAt: processedAt,
          lastWebhookEventType: eventType,
        },
      }),
    ]);

    return {
      duplicate: false,
      eventId: event.id,
      eventType,
    };
  } catch (error) {
    await prisma.whatsAppWebhookEvent.update({
      where: {
        id: event.id,
      },
      data: {
        errorMessage:
          error instanceof Error
            ? error.message.slice(0, 1000)
            : "Unknown webhook processing error.",
      },
    });
    throw error;
  }
}
