import { dispatchQueuedWhatsAppMessages } from "@/lib/whatsapp/outbox";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

function isAuthorized(request: Request) {
  const cronSecret = process.env.CRON_SECRET?.trim();
  return Boolean(
    cronSecret &&
      request.headers.get("authorization") === `Bearer ${cronSecret}`,
  );
}

export async function GET(request: Request) {
  if (!isAuthorized(request)) {
    return Response.json({ error: "Unauthorized." }, { status: 401 });
  }

  try {
    const result = await dispatchQueuedWhatsAppMessages(40);
    return Response.json({
      ok: true,
      ...result,
    });
  } catch (error) {
    console.error("WhatsApp outbox dispatch failed:", error);
    return Response.json(
      {
        ok: false,
        error:
          error instanceof Error
            ? error.message
            : "WhatsApp outbox dispatch failed.",
      },
      { status: 500 },
    );
  }
}
