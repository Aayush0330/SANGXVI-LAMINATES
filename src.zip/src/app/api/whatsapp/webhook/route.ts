import { createHash, createHmac, timingSafeEqual } from "node:crypto";
import {
  getWhatsAppAppSecret,
  getWhatsAppWebhookVerifyToken,
} from "@/lib/whatsapp/meta-cloud";
import {
  processWhatsAppWebhook,
  WhatsAppWebhookAssetMismatchError,
} from "@/lib/whatsapp/webhook";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

const MAX_WEBHOOK_BYTES = 1_048_576;

function constantTimeTextEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);

  if (leftBuffer.length !== rightBuffer.length) return false;
  return timingSafeEqual(leftBuffer, rightBuffer);
}

function validMetaSignature(rawBody: string, signature: string | null) {
  const appSecret = getWhatsAppAppSecret();

  if (!appSecret || !signature?.startsWith("sha256=")) return false;

  const expected = `sha256=${createHmac("sha256", appSecret)
    .update(rawBody)
    .digest("hex")}`;

  return constantTimeTextEqual(expected, signature);
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const mode = url.searchParams.get("hub.mode");
  const verifyToken = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge");
  const configuredToken = getWhatsAppWebhookVerifyToken();

  if (!configuredToken) {
    return new Response("Webhook verification is not configured.", {
      status: 503,
    });
  }

  if (
    mode !== "subscribe" ||
    !verifyToken ||
    !constantTimeTextEqual(configuredToken, verifyToken) ||
    !challenge
  ) {
    return new Response("Forbidden", { status: 403 });
  }

  return new Response(challenge, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
    },
  });
}

export async function POST(request: Request) {
  const declaredLength = Number(request.headers.get("content-length") ?? 0);

  if (declaredLength > MAX_WEBHOOK_BYTES) {
    return Response.json({ error: "Payload too large." }, { status: 413 });
  }

  const rawBody = await request.text();

  if (Buffer.byteLength(rawBody, "utf8") > MAX_WEBHOOK_BYTES) {
    return Response.json({ error: "Payload too large." }, { status: 413 });
  }

  if (!validMetaSignature(rawBody, request.headers.get("x-hub-signature-256"))) {
    return Response.json({ error: "Invalid signature." }, { status: 401 });
  }

  let payload: unknown;

  try {
    payload = JSON.parse(rawBody);
  } catch {
    return Response.json({ error: "Invalid JSON." }, { status: 400 });
  }

  const payloadHash = createHash("sha256").update(rawBody).digest("hex");

  try {
    const result = await processWhatsAppWebhook({
      payloadHash,
      payload,
    });

    return Response.json({
      ok: true,
      duplicate: result.duplicate,
    });
  } catch (error) {
    if (error instanceof WhatsAppWebhookAssetMismatchError) {
      return Response.json(
        { error: "Webhook asset mismatch." },
        { status: 403 },
      );
    }

    console.error("WhatsApp webhook processing failed:", error);
    return Response.json(
      { error: "Webhook processing failed." },
      { status: 500 },
    );
  }
}
