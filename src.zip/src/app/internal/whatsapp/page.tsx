import { AccessDeniedCard } from "@/components/access-denied-card";
import { checkPermission } from "@/lib/auth-guards";
import { prisma } from "@/lib/db";
import {
  ensureWhatsAppDefaults,
  getTemplateParameterKeys,
} from "@/lib/whatsapp/defaults";
import {
  getWhatsAppRuntimeStatus,
  maskWhatsAppPhone,
} from "@/lib/whatsapp/meta-cloud";
import {
  dispatchWhatsAppOutboxAction,
  retryWhatsAppMessageAction,
  saveWhatsAppSettingsAction,
  saveWhatsAppTemplateAction,
  sendWhatsAppTestAction,
} from "./actions";

export const dynamic = "force-dynamic";

type PageSearchParams = {
  success?: string;
  error?: string;
  detail?: string;
};

function formatDate(value: Date | null) {
  if (!value) return "Never";
  return new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  }).format(value);
}

function statusTone(status: string) {
  switch (status) {
    case "READ":
      return "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300";
    case "DELIVERED":
    case "SENT":
      return "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300";
    case "FAILED":
      return "bg-rose-100 text-rose-700 dark:bg-rose-500/15 dark:text-rose-300";
    case "RECEIVED":
      return "bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300";
    case "PROCESSING":
      return "bg-cyan-100 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300";
    default:
      return "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300";
  }
}

function configurationMessage(params: PageSearchParams) {
  if (params.success === "settings-saved") {
    return "WhatsApp configuration was saved.";
  }
  if (params.success === "template-saved") {
    return "Meta template mapping was saved.";
  }
  if (params.success === "test-sent") {
    return "Meta accepted the test message. Delivery and read updates will arrive through the webhook.";
  }
  if (params.success === "message-retried") {
    return "The WhatsApp message was retried successfully.";
  }
  if (params.success === "outbox-dispatched") {
    return `Outbox dispatch completed${params.detail ? `: ${params.detail}` : "."}`;
  }
  return null;
}

function errorMessage(params: PageSearchParams) {
  if (!params.error) return null;

  const labels: Record<string, string> = {
    "permission-denied": "You do not have permission to manage WhatsApp.",
    "invalid-business-name": "Enter a valid business display name.",
    "invalid-country-code": "Enter a 1–4 digit default country code.",
    "configuration-incomplete":
      "Automatic delivery cannot be enabled until all server credentials are configured.",
    "send-configuration-incomplete":
      "A test cannot be sent until the Meta send credentials are configured.",
    "invalid-event-key": "The WhatsApp event mapping is invalid.",
    "invalid-template-name":
      "Template names may contain only lowercase letters, numbers and underscores.",
    "invalid-language-code":
      "Use a valid language code such as en or en_US.",
    "template-not-found": "The selected template mapping was not found.",
    "test-failed": "The WhatsApp test message failed.",
    "dispatch-failed": "The WhatsApp outbox dispatch failed.",
    "retry-failed": "The WhatsApp message retry failed.",
    "message-not-retryable": "That message cannot be retried.",
    "missing-message": "The message ID is missing.",
  };

  return `${labels[params.error] ?? params.error.replaceAll("-", " ")}${params.detail ? ` ${params.detail}` : ""}`;
}

export default async function WhatsAppControlCenterPage({
  searchParams,
}: {
  searchParams?: Promise<PageSearchParams>;
}) {
  const { hasAccess } = await checkPermission(
    "manage_whatsapp",
    "/internal/whatsapp",
  );

  if (!hasAccess) {
    return (
      <AccessDeniedCard
        title="WhatsApp Access Denied"
        description="Only the owner can configure client credentials, template mappings and WhatsApp delivery controls."
        backHref="/internal/dashboard"
        backLabel="Go to Dashboard"
      />
    );
  }

  const params = (await searchParams) ?? {};
  const runtimeStatus = getWhatsAppRuntimeStatus();

  try {
    await ensureWhatsAppDefaults();
  } catch (error) {
    console.error("WhatsApp tables are not ready:", error);
    return (
      <div className="rounded-3xl border border-rose-200 bg-rose-50 p-6 text-rose-800 dark:border-rose-500/20 dark:bg-rose-500/10 dark:text-rose-200">
        <p className="text-xs font-black uppercase tracking-[0.25em]">
          WhatsApp migration required
        </p>
        <h1 className="mt-3 text-2xl font-black">
          The WhatsApp control tables are not ready
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-6">
          Apply the included Prisma migration, generate Prisma Client and
          restart the application before opening this page.
        </p>
        <pre className="mt-5 overflow-x-auto rounded-2xl border border-rose-200 bg-white p-4 text-xs dark:border-rose-500/20 dark:bg-slate-950">{`npm run db:deploy
npx prisma generate
npm run dev`}</pre>
      </div>
    );
  }

  const [configuration, templates, messages, webhookEventCount] =
    await Promise.all([
      prisma.whatsAppConfiguration.findUniqueOrThrow({
        where: {
          id: "primary",
        },
      }),
      prisma.whatsAppTemplate.findMany({
        orderBy: [{ eventKey: "asc" }],
      }),
      prisma.whatsAppMessage.findMany({
        orderBy: {
          createdAt: "desc",
        },
        take: 60,
      }),
      prisma.whatsAppWebhookEvent.count(),
    ]);

  const pendingCount = messages.filter((message) =>
    ["PENDING", "PROCESSING"].includes(message.status),
  ).length;
  const failedCount = messages.filter(
    (message) => message.status === "FAILED",
  ).length;
  const deliveredCount = messages.filter((message) =>
    ["DELIVERED", "READ"].includes(message.status),
  ).length;
  const enabledBusinessTemplates = templates.filter(
    (template) =>
      template.eventKey !== "TEST_MESSAGE" && template.isEnabled,
  ).length;
  const success = configurationMessage(params);
  const error = errorMessage(params);
  const configuredChecks = [
    {
      label: "Graph API version",
      ready: runtimeStatus.graphApiVersionConfigured,
      detail: "Set from the client Meta App dashboard.",
    },
    {
      label: "Phone Number ID",
      ready: runtimeStatus.phoneNumberIdConfigured,
      detail: runtimeStatus.maskedPhoneNumberId ?? "Not configured",
    },
    {
      label: "WhatsApp Business Account ID",
      ready: runtimeStatus.wabaIdConfigured,
      detail: runtimeStatus.maskedWabaId ?? "Not configured",
    },
    {
      label: "Permanent access token",
      ready: runtimeStatus.accessTokenConfigured,
      detail: runtimeStatus.accessTokenConfigured
        ? "Configured on server"
        : "Not configured",
    },
    {
      label: "Signed webhook",
      ready: runtimeStatus.webhookReady,
      detail: runtimeStatus.webhookReady
        ? "App Secret and verify token configured"
        : "App Secret or verify token missing",
    },
  ];

  return (
    <div className="space-y-6 pb-8">
      <section className="overflow-hidden rounded-3xl border border-emerald-200 bg-gradient-to-br from-white via-white to-emerald-50 shadow-sm shadow-emerald-100/60 dark:border-emerald-500/20 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/30 dark:shadow-none">
        <div className="grid gap-6 p-6 lg:grid-cols-[1fr_auto] lg:items-end lg:p-8">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-[10px] font-black uppercase tracking-[0.2em] text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                Direct Meta Cloud API
              </span>
              <span
                className={`rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-[0.2em] ${
                  configuration.isEnabled
                    ? "bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300"
                    : "bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-300"
                }`}
              >
                Automation {configuration.isEnabled ? "enabled" : "disabled"}
              </span>
            </div>
            <h1 className="mt-4 text-3xl font-black tracking-tight text-slate-950 dark:text-white sm:text-4xl">
              WhatsApp Control Center
            </h1>
            <p className="mt-3 max-w-3xl text-sm leading-6 text-slate-600 dark:text-slate-300">
              Secure Meta template delivery, retryable outbox, signed webhook
              processing and delivery/read audit history for Sanghvi ERP.
              Tokens and App Secret are never stored in this page or database.
            </p>
          </div>
          <div className="rounded-2xl border border-emerald-200 bg-white/80 px-5 py-4 dark:border-emerald-500/20 dark:bg-slate-950/60">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
              Webhook endpoint
            </p>
            <code className="mt-2 block text-sm font-bold text-emerald-700 dark:text-emerald-300">
              /api/whatsapp/webhook
            </code>
          </div>
        </div>
      </section>

      {success ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm font-bold text-emerald-800 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-200">
          {success}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-2xl border border-rose-200 bg-rose-50 px-5 py-4 text-sm font-bold text-rose-800 dark:border-rose-500/20 dark:bg-rose-500/10 dark:text-rose-200">
          {error}
        </div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            label: "Runtime",
            value: runtimeStatus.automaticReady ? "Ready" : "Setup needed",
            detail: runtimeStatus.automaticReady
              ? "Send + webhook credentials ready"
              : `${runtimeStatus.missingForAutomatic.length} required value(s) missing`,
            tone: runtimeStatus.automaticReady ? "emerald" : "amber",
          },
          {
            label: "Outbox",
            value: String(pendingCount),
            detail: "Pending or processing",
            tone: pendingCount > 0 ? "amber" : "slate",
          },
          {
            label: "Delivered",
            value: String(deliveredCount),
            detail: "Latest 60 records",
            tone: "blue",
          },
          {
            label: "Failed",
            value: String(failedCount),
            detail: "Manual retry available",
            tone: failedCount > 0 ? "rose" : "slate",
          },
        ].map((card) => (
          <div
            key={card.label}
            className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none"
          >
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">
              {card.label}
            </p>
            <p
              className={`mt-3 text-2xl font-black ${
                card.tone === "emerald"
                  ? "text-emerald-700 dark:text-emerald-300"
                  : card.tone === "amber"
                    ? "text-amber-700 dark:text-amber-300"
                    : card.tone === "blue"
                      ? "text-blue-700 dark:text-blue-300"
                      : card.tone === "rose"
                        ? "text-rose-700 dark:text-rose-300"
                        : "text-slate-950 dark:text-white"
              }`}
            >
              {card.value}
            </p>
            <p className="mt-1 text-xs font-semibold text-slate-400">
              {card.detail}
            </p>
          </div>
        ))}
      </section>

      <section className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-blue-600 dark:text-blue-300">
                Server connection
              </p>
              <h2 className="mt-2 text-2xl font-black text-slate-950 dark:text-white">
                Client credential readiness
              </h2>
            </div>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-slate-500 dark:bg-slate-800 dark:text-slate-300">
              Secrets hidden
            </span>
          </div>
          <div className="mt-5 divide-y divide-slate-100 dark:divide-slate-800">
            {configuredChecks.map((check) => (
              <div
                key={check.label}
                className="flex items-start gap-3 py-4 first:pt-0 last:pb-0"
              >
                <span
                  className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-black ${
                    check.ready
                      ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                      : "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"
                  }`}
                >
                  {check.ready ? "✓" : "!"}
                </span>
                <div>
                  <p className="text-sm font-black text-slate-800 dark:text-slate-100">
                    {check.label}
                  </p>
                  <p className="mt-1 text-xs font-semibold text-slate-400">
                    {check.detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-xs leading-5 text-blue-800 dark:border-blue-500/20 dark:bg-blue-500/10 dark:text-blue-200">
            Configure values in the deployment environment. Never paste access
            tokens or App Secret into ERP forms, source code, screenshots or
            support chats.
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-emerald-600 dark:text-emerald-300">
            Operating controls
          </p>
          <h2 className="mt-2 text-2xl font-black text-slate-950 dark:text-white">
            Safe rollout
          </h2>
          <form action={saveWhatsAppSettingsAction} className="mt-5 space-y-4">
            <label className="block">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
                Business display name
              </span>
              <input
                name="businessDisplayName"
                defaultValue={configuration.businessDisplayName}
                required
                maxLength={80}
                className="mt-2 h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-950 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-950 dark:text-white dark:focus:ring-blue-500/10"
              />
            </label>
            <label className="block">
              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
                Default country code
              </span>
              <input
                name="defaultCountryCode"
                defaultValue={configuration.defaultCountryCode}
                inputMode="numeric"
                required
                maxLength={4}
                className="mt-2 h-12 w-full rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-950 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-950 dark:text-white dark:focus:ring-blue-500/10"
              />
            </label>
            <label className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950">
              <input
                type="checkbox"
                name="isEnabled"
                defaultChecked={configuration.isEnabled}
                className="mt-0.5 h-5 w-5 rounded border-slate-300 text-emerald-600"
              />
              <span>
                <span className="block text-sm font-black text-slate-800 dark:text-slate-100">
                  Enable automatic WhatsApp delivery
                </span>
                <span className="mt-1 block text-xs leading-5 text-slate-500 dark:text-slate-400">
                  Activation is blocked until send, account and signed webhook
                  credentials are complete.
                </span>
              </span>
            </label>
            <button
              type="submit"
              className="inline-flex h-12 items-center justify-center rounded-xl bg-slate-950 px-5 text-sm font-black text-white transition hover:bg-slate-800 dark:bg-white dark:text-slate-950"
            >
              Save Controls
            </button>
          </form>
          <p className="mt-4 text-xs font-semibold text-slate-400">
            Last webhook: {formatDate(configuration.lastWebhookAt)}
            {configuration.lastWebhookEventType
              ? ` · ${configuration.lastWebhookEventType.replaceAll("_", " ")}`
              : ""}
          </p>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[0.8fr_1.2fr]">
        <div className="rounded-3xl border border-emerald-200 bg-gradient-to-br from-white to-emerald-50 p-6 dark:border-emerald-500/20 dark:from-slate-900 dark:to-emerald-950/20">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-emerald-700 dark:text-emerald-300">
            Live connection test
          </p>
          <h2 className="mt-2 text-2xl font-black text-slate-950 dark:text-white">
            Send Meta hello_world
          </h2>
          <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">
            Uses the configured TEST_MESSAGE mapping. The master automation
            switch may remain off during this controlled owner test.
          </p>
          <form action={sendWhatsAppTestAction} className="mt-5">
            <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
              Approved test recipient
            </label>
            <input
              name="recipientPhone"
              type="tel"
              required
              placeholder="+919876543210"
              className="mt-2 h-12 w-full rounded-xl border border-emerald-200 bg-white px-4 text-sm font-semibold text-slate-950 outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 dark:border-emerald-500/20 dark:bg-slate-950 dark:text-white"
            />
            <button
              type="submit"
              className="mt-4 inline-flex h-12 items-center justify-center rounded-xl bg-emerald-600 px-5 text-sm font-black text-white transition hover:bg-emerald-700"
            >
              Send Test Message
            </button>
          </form>
          <p className="mt-4 text-xs leading-5 text-slate-500 dark:text-slate-400">
            Use only a client-authorized test number. Meta test-recipient and
            template restrictions still apply.
          </p>
        </div>

        <div className="rounded-3xl border border-amber-200 bg-amber-50 p-6 dark:border-amber-500/20 dark:bg-amber-500/10">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-amber-700 dark:text-amber-300">
            Production gate
          </p>
          <h2 className="mt-2 text-2xl font-black text-slate-950 dark:text-white">
            Business events are staged, not blindly enabled
          </h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            {[
              "Meta templates approved",
              "Client numbers and consent verified",
              "Webhook delivery confirmed",
              "Event-to-recipient rules reviewed",
            ].map((item) => (
              <div
                key={item}
                className="rounded-2xl border border-amber-200 bg-white/70 px-4 py-3 text-sm font-bold text-amber-900 dark:border-amber-500/20 dark:bg-slate-950/30 dark:text-amber-100"
              >
                {item}
              </div>
            ))}
          </div>
          <p className="mt-4 text-sm leading-6 text-amber-900/80 dark:text-amber-100/80">
            Phase 1 provides the secure transport and audit foundation.
            Order, delivery, low-stock and blocker triggers should be connected
            only after approved template names and recipient opt-in rules are
            confirmed with the client.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            <form action={dispatchWhatsAppOutboxAction}>
              <button
                type="submit"
                disabled={!configuration.isEnabled}
                className="inline-flex h-11 items-center justify-center rounded-xl bg-amber-600 px-4 text-sm font-black text-white transition hover:bg-amber-700 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Dispatch Due Outbox
              </button>
            </form>
            <span className="text-xs font-bold text-amber-800 dark:text-amber-200">
              {enabledBusinessTemplates} business template(s) enabled
            </span>
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-violet-600 dark:text-violet-300">
              Meta templates
            </p>
            <h2 className="mt-2 text-2xl font-black text-slate-950 dark:text-white">
              Event mapping registry
            </h2>
          </div>
          <p className="text-xs font-semibold text-slate-400">
            Template names must exactly match Meta · {templates.length} mappings
          </p>
        </div>
        <div className="mt-5 grid gap-4 xl:grid-cols-2">
          {templates.map((template) => {
            const parameterKeys = getTemplateParameterKeys(
              template.parameterKeys,
            );

            return (
              <form
                key={template.id}
                action={saveWhatsAppTemplateAction}
                className="rounded-2xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-700 dark:bg-slate-950"
              >
                <input type="hidden" name="eventKey" value={template.eventKey} />
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-sm font-black text-slate-950 dark:text-white">
                      {template.displayName}
                    </p>
                    <p className="mt-1 font-mono text-[10px] font-bold text-slate-400">
                      {template.eventKey}
                    </p>
                  </div>
                  <label className="flex items-center gap-2 text-xs font-black text-slate-600 dark:text-slate-300">
                    <input
                      type="checkbox"
                      name="isEnabled"
                      defaultChecked={template.isEnabled}
                      className="h-4 w-4 rounded border-slate-300 text-emerald-600"
                    />
                    Enabled
                  </label>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-[1fr_120px]">
                  <label>
                    <span className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">
                      Meta template name
                    </span>
                    <input
                      name="templateName"
                      defaultValue={template.templateName}
                      required
                      pattern="[a-z0-9_]+"
                      className="mt-2 h-11 w-full rounded-xl border border-slate-200 bg-white px-3 font-mono text-xs font-bold text-slate-800 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                    />
                  </label>
                  <label>
                    <span className="text-[10px] font-black uppercase tracking-[0.18em] text-slate-400">
                      Language
                    </span>
                    <input
                      name="languageCode"
                      defaultValue={template.languageCode}
                      required
                      className="mt-2 h-11 w-full rounded-xl border border-slate-200 bg-white px-3 font-mono text-xs font-bold text-slate-800 outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                    />
                  </label>
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                  <p className="text-[11px] font-semibold text-slate-400">
                    Parameters:{" "}
                    {parameterKeys.length > 0
                      ? parameterKeys.join(", ")
                      : "none"}
                  </p>
                  <button
                    type="submit"
                    className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-black text-slate-700 transition hover:border-blue-300 hover:text-blue-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                  >
                    Save Mapping
                  </button>
                </div>
              </form>
            );
          })}
        </div>
      </section>

      <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm shadow-slate-200/50 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-slate-400">
              Delivery audit
            </p>
            <h2 className="mt-2 text-2xl font-black text-slate-950 dark:text-white">
              Message history
            </h2>
          </div>
          <p className="text-xs font-semibold text-slate-400">
            Latest {messages.length} messages · {webhookEventCount} verified
            webhook event(s)
          </p>
        </div>
        <div className="mt-5 overflow-x-auto">
          <table className="min-w-[980px] w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-[10px] font-black uppercase tracking-[0.16em] text-slate-400 dark:border-slate-800">
                <th className="py-3 pr-4">Direction</th>
                <th className="py-3 pr-4">Event</th>
                <th className="py-3 pr-4">Contact</th>
                <th className="py-3 pr-4">Template</th>
                <th className="py-3 pr-4">Status</th>
                <th className="py-3 pr-4">Attempts</th>
                <th className="py-3 pr-4">Created</th>
                <th className="py-3">Action</th>
              </tr>
            </thead>
            <tbody>
              {messages.map((message) => (
                <tr
                  key={message.id}
                  className="border-b border-slate-100 align-top dark:border-slate-800/70"
                >
                  <td className="py-4 pr-4 font-black text-slate-700 dark:text-slate-200">
                    {message.direction === "INBOUND" ? "Inbound" : "Outbound"}
                  </td>
                  <td className="py-4 pr-4">
                    <p className="font-bold text-slate-700 dark:text-slate-200">
                      {(message.eventKey ?? "—").replaceAll("_", " ")}
                    </p>
                    {message.errorMessage ? (
                      <p
                        className="mt-1 max-w-[260px] truncate text-xs font-semibold text-rose-600 dark:text-rose-300"
                        title={message.errorMessage}
                      >
                        {message.errorMessage}
                      </p>
                    ) : null}
                  </td>
                  <td className="py-4 pr-4 font-semibold text-slate-500">
                    {maskWhatsAppPhone(
                      message.direction === "INBOUND"
                        ? message.senderPhone
                        : message.recipientPhone,
                    )}
                  </td>
                  <td className="py-4 pr-4 font-mono text-xs font-bold text-slate-500">
                    {message.templateName ?? "Inbound message"}
                  </td>
                  <td className="py-4 pr-4">
                    <span
                      className={`rounded-full px-2.5 py-1 text-[10px] font-black uppercase ${statusTone(message.status)}`}
                    >
                      {message.status}
                    </span>
                  </td>
                  <td className="py-4 pr-4 font-bold text-slate-500">
                    {message.attempts}
                  </td>
                  <td className="py-4 pr-4 text-xs font-semibold text-slate-500">
                    {formatDate(message.createdAt)}
                  </td>
                  <td className="py-4">
                    {message.direction === "OUTBOUND" &&
                    ["FAILED", "PENDING"].includes(message.status) ? (
                      <form action={retryWhatsAppMessageAction}>
                        <input
                          type="hidden"
                          name="messageId"
                          value={message.id}
                        />
                        <button
                          type="submit"
                          className="text-xs font-black text-blue-600 hover:text-blue-800 dark:text-blue-300"
                        >
                          Retry now
                        </button>
                      </form>
                    ) : (
                      <span className="text-slate-300 dark:text-slate-700">—</span>
                    )}
                  </td>
                </tr>
              ))}
              {messages.length === 0 ? (
                <tr>
                  <td
                    colSpan={8}
                    className="py-10 text-center text-sm font-semibold text-slate-400"
                  >
                    No WhatsApp messages have been recorded yet.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
