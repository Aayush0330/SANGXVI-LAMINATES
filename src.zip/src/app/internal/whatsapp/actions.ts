"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { checkPermission } from "@/lib/auth-guards";
import { prisma } from "@/lib/db";
import { createSecurityAuditLog } from "@/lib/security-audit";
import {
  ensureWhatsAppDefaults,
  isWhatsAppEventKey,
} from "@/lib/whatsapp/defaults";
import {
  dispatchQueuedWhatsAppMessages,
  dispatchWhatsAppMessageById,
  queueWhatsAppTemplateMessage,
  resetWhatsAppMessageForRetry,
} from "@/lib/whatsapp/outbox";
import {
  getWhatsAppRuntimeStatus,
  validateWhatsAppLanguageCode,
  validateWhatsAppTemplateName,
} from "@/lib/whatsapp/meta-cloud";

const WHATSAPP_PATH = "/internal/whatsapp";

function clean(value: FormDataEntryValue | null) {
  return String(value ?? "").trim();
}

function feedbackUrl(
  type: "success" | "error",
  code: string,
  detail?: string,
) {
  const params = new URLSearchParams({
    [type]: code,
  });

  if (detail) {
    params.set("detail", detail.slice(0, 240));
  }

  return `${WHATSAPP_PATH}?${params.toString()}`;
}

async function authorizeWhatsAppManagement() {
  const result = await checkPermission("manage_whatsapp", WHATSAPP_PATH);

  if (!result.hasAccess) {
    redirect(feedbackUrl("error", "permission-denied"));
  }

  return result.currentUser;
}

export async function saveWhatsAppSettingsAction(formData: FormData) {
  const currentUser = await authorizeWhatsAppManagement();
  const businessDisplayName = clean(formData.get("businessDisplayName"));
  const defaultCountryCode = clean(formData.get("defaultCountryCode")).replace(
    /\D/g,
    "",
  );
  const isEnabled = formData.get("isEnabled") === "on";

  if (
    businessDisplayName.length < 2 ||
    businessDisplayName.length > 80
  ) {
    redirect(feedbackUrl("error", "invalid-business-name"));
  }

  if (!/^\d{1,4}$/.test(defaultCountryCode)) {
    redirect(feedbackUrl("error", "invalid-country-code"));
  }

  const runtimeStatus = getWhatsAppRuntimeStatus();

  if (isEnabled && !runtimeStatus.automaticReady) {
    redirect(
      feedbackUrl(
        "error",
        "configuration-incomplete",
        runtimeStatus.missingForAutomatic.join(", "),
      ),
    );
  }

  await prisma.whatsAppConfiguration.upsert({
    where: {
      id: "primary",
    },
    update: {
      provider: "META_CLOUD",
      isEnabled,
      businessDisplayName,
      defaultCountryCode,
      updatedById: currentUser.id,
      updatedByName: currentUser.name,
    },
    create: {
      id: "primary",
      provider: "META_CLOUD",
      isEnabled,
      businessDisplayName,
      defaultCountryCode,
      updatedById: currentUser.id,
      updatedByName: currentUser.name,
    },
  });

  await createSecurityAuditLog({
    eventType: "WHATSAPP_SETTINGS_UPDATED",
    user: currentUser,
    path: WHATSAPP_PATH,
    description: `Updated Direct Meta Cloud API settings. Automatic delivery ${isEnabled ? "enabled" : "disabled"}.`,
  });

  revalidatePath(WHATSAPP_PATH);
  redirect(feedbackUrl("success", "settings-saved"));
}

export async function saveWhatsAppTemplateAction(formData: FormData) {
  const currentUser = await authorizeWhatsAppManagement();
  const eventKey = clean(formData.get("eventKey"));
  const templateName = clean(formData.get("templateName")).toLowerCase();
  const languageCode = clean(formData.get("languageCode"));
  const isEnabled = formData.get("isEnabled") === "on";

  if (!isWhatsAppEventKey(eventKey)) {
    redirect(feedbackUrl("error", "invalid-event-key"));
  }

  if (!validateWhatsAppTemplateName(templateName)) {
    redirect(feedbackUrl("error", "invalid-template-name"));
  }

  if (!validateWhatsAppLanguageCode(languageCode)) {
    redirect(feedbackUrl("error", "invalid-language-code"));
  }

  const template = await prisma.whatsAppTemplate.findUnique({
    where: {
      eventKey,
    },
  });

  if (!template) {
    redirect(feedbackUrl("error", "template-not-found"));
  }

  await prisma.whatsAppTemplate.update({
    where: {
      eventKey,
    },
    data: {
      templateName,
      languageCode,
      isEnabled,
    },
  });

  await createSecurityAuditLog({
    eventType: "WHATSAPP_SETTINGS_UPDATED",
    user: currentUser,
    path: WHATSAPP_PATH,
    description: `Updated WhatsApp template ${eventKey} to ${templateName} (${languageCode}); ${isEnabled ? "enabled" : "disabled"}.`,
  });

  revalidatePath(WHATSAPP_PATH);
  redirect(feedbackUrl("success", "template-saved"));
}

export async function sendWhatsAppTestAction(formData: FormData) {
  const currentUser = await authorizeWhatsAppManagement();
  const recipientPhone = clean(formData.get("recipientPhone"));
  const runtimeStatus = getWhatsAppRuntimeStatus();

  if (!runtimeStatus.sendReady) {
    redirect(
      feedbackUrl(
        "error",
        "send-configuration-incomplete",
        runtimeStatus.missingForSend.join(", "),
      ),
    );
  }

  await ensureWhatsAppDefaults();

  try {
    const message = await queueWhatsAppTemplateMessage({
      eventKey: "TEST_MESSAGE",
      recipientPhone,
      recipientName: "WhatsApp setup test",
      createdById: currentUser.id,
      createdByName: currentUser.name,
      allowWhenDisabled: true,
    });

    const sentMessage = await dispatchWhatsAppMessageById(message.id, {
      allowWhenDisabled: true,
      finalOnFailure: true,
    });

    await createSecurityAuditLog({
      eventType: "WHATSAPP_TEST_SENT",
      user: currentUser,
      path: WHATSAPP_PATH,
      description: `Sent Meta Cloud API test message ${sentMessage.id}.`,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "WhatsApp test failed.";
    revalidatePath(WHATSAPP_PATH);
    redirect(feedbackUrl("error", "test-failed", message));
  }

  revalidatePath(WHATSAPP_PATH);
  redirect(feedbackUrl("success", "test-sent"));
}

export async function dispatchWhatsAppOutboxAction() {
  await authorizeWhatsAppManagement();
  let result: Awaited<ReturnType<typeof dispatchQueuedWhatsAppMessages>>;

  try {
    result = await dispatchQueuedWhatsAppMessages(40);
  } catch (error) {
    redirect(
      feedbackUrl(
        "error",
        "dispatch-failed",
        error instanceof Error ? error.message : "Outbox dispatch failed.",
      ),
    );
  }

  revalidatePath(WHATSAPP_PATH);
  redirect(
    feedbackUrl(
      "success",
      "outbox-dispatched",
      `${result.sent} sent, ${result.failed} failed, ${result.selected} selected`,
    ),
  );
}

export async function retryWhatsAppMessageAction(formData: FormData) {
  const currentUser = await authorizeWhatsAppManagement();
  const messageId = clean(formData.get("messageId"));

  if (!messageId) {
    redirect(feedbackUrl("error", "missing-message"));
  }

  const existing = await prisma.whatsAppMessage.findUnique({
    where: {
      id: messageId,
    },
  });

  if (
    !existing ||
    existing.direction !== "OUTBOUND" ||
    !["FAILED", "PENDING"].includes(existing.status)
  ) {
    redirect(feedbackUrl("error", "message-not-retryable"));
  }

  const allowWhenDisabled = existing.eventKey === "TEST_MESSAGE";

  try {
    await resetWhatsAppMessageForRetry(existing.id);
    await dispatchWhatsAppMessageById(existing.id, {
      allowWhenDisabled,
      finalOnFailure: true,
    });

    await createSecurityAuditLog({
      eventType: "WHATSAPP_MESSAGE_RETRIED",
      user: currentUser,
      path: WHATSAPP_PATH,
      description: `Retried WhatsApp message ${existing.id}.`,
    });
  } catch (error) {
    revalidatePath(WHATSAPP_PATH);
    redirect(
      feedbackUrl(
        "error",
        "retry-failed",
        error instanceof Error ? error.message : "Message retry failed.",
      ),
    );
  }

  revalidatePath(WHATSAPP_PATH);
  redirect(feedbackUrl("success", "message-retried"));
}
