"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ErpIcon } from "@/components/erp-icon";
import type { NavigationItem } from "@/lib/navigation";

function normalize(value: string) {
  return value.trim().toLowerCase();
}

function getModuleGroup(item: NavigationItem) {
  if (
    [
      "/internal/dashboard",
      "/internal/orders",
      "/account/tasks",
      "/internal/inquiries",
    ].includes(item.href)
  ) {
    return "Main";
  }
  if (
    item.href.includes("attendance") ||
    item.href.includes("payroll") ||
    item.href.includes("/hr") ||
    item.href.includes("/teams") ||
    item.href.includes("/tasks")
  ) {
    return "Workforce";
  }
  if (
    item.href.includes("inventory") ||
    item.href.includes("dispatch") ||
    item.href.includes("qc") ||
    item.href.includes("transport") ||
    item.href.includes("delivery") ||
    item.href.includes("collections") ||
    item.href.includes("reorder")
  ) {
    return "Operations";
  }
  return "Administration";
}

export function InternalCommandMenu({
  items,
  compact = false,
  enableShortcut = true,
}: {
  items: NavigationItem[];
  compact?: boolean;
  enableShortcut?: boolean;
}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);

  const results = useMemo(() => {
    const normalizedQuery = normalize(query);
    const filtered = normalizedQuery
      ? items.filter((item) =>
          normalize(`${item.label} ${item.href} ${getModuleGroup(item)}`).includes(
            normalizedQuery,
          ),
        )
      : items;

    return filtered.slice(0, 9);
  }, [items, query]);

  const openMenu = useCallback(() => {
    setQuery("");
    setActiveIndex(0);
    setOpen(true);
  }, []);

  useEffect(() => {
    if (!enableShortcut) return;

    function handleShortcut(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        if (open) {
          setOpen(false);
        } else {
          openMenu();
        }
      }
      if (event.key === "Escape") {
        setOpen(false);
      }
    }

    window.addEventListener("keydown", handleShortcut);
    return () => window.removeEventListener("keydown", handleShortcut);
  }, [enableShortcut, open, openMenu]);

  useEffect(() => {
    if (!open) return;
    const frame = window.requestAnimationFrame(() => inputRef.current?.focus());
    return () => window.cancelAnimationFrame(frame);
  }, [open]);

  function navigateTo(item: NavigationItem) {
    setOpen(false);
    router.push(item.href);
  }

  return (
    <>
      <button
        type="button"
        onClick={openMenu}
        className={`group flex items-center rounded-xl border border-slate-200 bg-slate-50 text-left font-medium text-slate-400 transition hover:border-slate-300 hover:bg-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 dark:border-white/10 dark:bg-slate-900 dark:hover:border-white/20 dark:hover:bg-slate-900 ${
          compact
            ? "h-10 w-10 justify-center"
            : "h-11 w-full max-w-[520px] gap-3 px-4 text-sm"
        }`}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={compact ? "Open ERP command menu" : undefined}
      >
        <ErpIcon
          name="search"
          className="h-4.5 w-4.5 shrink-0 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-300"
        />
        {compact ? null : (
          <>
            <span className="min-w-0 flex-1 truncate">
              Search modules and commands
            </span>
            <span className="hidden items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 font-mono text-[10px] font-bold text-slate-400 sm:inline-flex dark:border-white/10 dark:bg-slate-950">
              Ctrl K
            </span>
          </>
        )}
      </button>

      {open ? (
        <div
          className="fixed inset-0 z-[90] flex items-start justify-center bg-slate-950/55 px-4 pt-[10vh] backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setOpen(false);
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="ERP command menu"
            className="w-full max-w-2xl overflow-hidden rounded-2xl border border-white/10 bg-white shadow-[0_28px_80px_rgba(15,23,42,0.32)] dark:bg-slate-900"
          >
            <div className="flex items-center gap-3 border-b border-slate-200 px-4 dark:border-white/10">
              <ErpIcon name="search" className="h-5 w-5 text-slate-400" />
              <input
                ref={inputRef}
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setActiveIndex(0);
                }}
                onKeyDown={(event) => {
                  if (event.key === "ArrowDown") {
                    event.preventDefault();
                    setActiveIndex((current) =>
                      Math.min(current + 1, Math.max(0, results.length - 1)),
                    );
                  }
                  if (event.key === "ArrowUp") {
                    event.preventDefault();
                    setActiveIndex((current) => Math.max(0, current - 1));
                  }
                  if (event.key === "Enter" && results[activeIndex]) {
                    event.preventDefault();
                    navigateTo(results[activeIndex]);
                  }
                }}
                placeholder="Search orders, inventory, reports..."
                className="h-16 min-w-0 flex-1 border-0 bg-transparent text-base font-semibold text-slate-950 outline-none placeholder:text-slate-400 dark:text-white"
                role="combobox"
                aria-label="Search authorized ERP modules"
                aria-autocomplete="list"
                aria-expanded="true"
                aria-controls="erp-command-results"
                aria-activedescendant={
                  results[activeIndex]
                    ? `erp-command-${activeIndex}`
                    : undefined
                }
              />
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-white/10 dark:hover:text-white"
                aria-label="Close command menu"
              >
                <ErpIcon name="close" className="h-4 w-4" />
              </button>
            </div>

            <div
              id="erp-command-results"
              role="listbox"
              className="max-h-[55vh] overflow-y-auto p-2"
            >
              {results.length === 0 ? (
                <div className="px-4 py-12 text-center">
                  <p className="text-sm font-bold text-slate-900 dark:text-white">
                    No matching module
                  </p>
                  <p className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">
                    Try a module name such as orders, inventory or reports.
                  </p>
                </div>
              ) : (
                results.map((item, index) => (
                  <button
                    key={item.href}
                    id={`erp-command-${index}`}
                    type="button"
                    role="option"
                    aria-selected={activeIndex === index}
                    onMouseEnter={() => setActiveIndex(index)}
                    onClick={() => navigateTo(item)}
                    className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition ${
                      activeIndex === index
                        ? "bg-blue-50 text-blue-800 dark:bg-blue-400/10 dark:text-blue-200"
                        : "text-slate-700 hover:bg-slate-50 dark:text-slate-300 dark:hover:bg-white/5"
                    }`}
                  >
                    <span
                      className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${
                        activeIndex === index
                          ? "bg-white text-blue-700 shadow-sm dark:bg-blue-400/10 dark:text-blue-200"
                          : "bg-slate-100 text-slate-500 dark:bg-white/10 dark:text-slate-400"
                      }`}
                    >
                      <ErpIcon
                        name={
                          item.href.includes("inventory")
                            ? "inventory"
                            : item.href.includes("order")
                              ? "orders"
                              : item.href.includes("collection")
                                ? "collection"
                                : item.href.includes("task")
                                  ? "tasks"
                                  : "dashboard"
                        }
                        className="h-4.5 w-4.5"
                      />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-bold">
                        {item.label}
                      </span>
                      <span className="mt-0.5 block text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-400">
                        {getModuleGroup(item)}
                      </span>
                    </span>
                    <span className="font-mono text-[10px] font-bold text-slate-400">
                      ↵
                    </span>
                  </button>
                ))
              )}
            </div>

            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-slate-200 bg-slate-50 px-4 py-3 text-[10px] font-semibold text-slate-400 dark:border-white/10 dark:bg-slate-950">
              <span>↑↓ Navigate</span>
              <span>↵ Open</span>
              <span>Esc Close</span>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
